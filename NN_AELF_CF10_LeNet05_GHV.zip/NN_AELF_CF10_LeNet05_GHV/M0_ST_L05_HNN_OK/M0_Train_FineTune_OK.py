# Import system modules-------------------------------------
import time
import torch
from torch.optim import lr_scheduler
# Import system modules-------------------------------------
from Base_Setting_Function.F0_Setting_L05_CF10 import Config
from Base_Setting_Function.F2_Test_Method_OK import Test_Method_NewModel
from Base_Setting_Function.F4_LossFunction_OK import Label_CELF0

# Train the CNN model ==================================================
def Train_Function(Model, TrainData_Loader, Lamda, Epoch0, TestData_Loader):

    torch.save(Model.state_dict(), Config.Model.Model_Path + 'CF10_L05_CEOF0.pkl')
    print('-------------------------------')
    print('|| CELF:', 'True')
    print('-------------------------------')

    Label_CELFModel = Label_CELF0()

    # Set the GPU devices--------------------------------
    if torch.cuda.is_available():
        Model.cuda()
        Label_CELFModel.cuda()
    # Set the GPU devices-------------------------------- 

    L2Norm = Config.Train.RFlag_L2Norm #
    LR0 = Config.Train.LR_SGD_LR0 #
    LR_M_Epoch_Num = Config.Train.LR_SGD_M_Epoch
    LR_M_Epoch_BiLi = Config.Train.LR_SGD_M_BiLi
    print('Training setting---------------')
    print('|| LR0:', LR0, 'LR_M:', LR_M_Epoch_Num, 'LR_BiLi:', LR_M_Epoch_BiLi, '| Weight_Decay0:', L2Norm,
          '| AE:', None, '| DropOut:', Config.Train.RFlag_Dropout)
    print('Training setting---------------')

    Optimizer_Model = torch.optim.SGD(Model.parameters(), lr=LR0, momentum=0.9, weight_decay=L2Norm)
    Scheduler_Model = lr_scheduler.MultiStepLR(Optimizer_Model, milestones=[40, 80], gamma=0.1, last_epoch=-1)
    # Define the train parameters and loss function---------------------------------------------

    # training the CNN model----------------------------------------------
    TestRecord_NA_Dict = {}
    TestRate_Best = [0, 0]
    for Epoch in range(0, Epoch0):
        Start_Time = time.time()
        RandomSeed = Config.OS.RandomSeed

        Label_NL_CELFView = 0

        if Epoch == 0:
            TestRate_N, TestRate_A = Test_Method_NewModel(Model, TestData_Loader, Method_Flag='CELF', A_Test=False)
            TestRecord_NA_Dict.update({Epoch + 1: [(TestRate_N, TestRate_A),(None)]})

        for StepI, (N_Image0, N_Label0) in enumerate(TrainData_Loader):
            # Normal Train------------------
            NN_Image = N_Image0.cuda()  # Image of the batch
            NN_Label = N_Label0.cuda()

            Label_N_CEFOut, (Label_N_COFOut, Feature_N_Out) = Model(NN_Image, Label='Label')  # cnn output
            NLabel_CELFOut = Label_CELFModel(Label_N_CEFOut, NN_Label)

            Optimizer_Model.zero_grad()
            NLabel_CELFOut.backward()
            Optimizer_Model.step()
            # Normal Train------------------

            # Eval error--------------------------------------
            Label_NL_CELFView = Label_NL_CELFView + NLabel_CELFOut.item()

        Scheduler_Model.step()

        print('Error Data==============================================')
        End_Time = time.time()
        Epoch_Time = round((End_Time - Start_Time)/60, 2)
        print('[| Epoch:', Epoch+1, "| OS RandomSeed:", RandomSeed, '| LR:',
              round(Optimizer_Model.param_groups[0]['lr'], 6), '| L2Norm:', L2Norm, '| Time:', Epoch_Time, '|]')

        Label_NAL_CELFView_Epoch = round(Label_NL_CELFView / (StepI + 1), 4)
        Label_NL_CELFView_Epoch = round(Label_NL_CELFView / (StepI + 1), 4)

        print('Error Data----------------------------------')
        print('NAL_CELF in Epoch(%d):' % (Epoch + 1), Label_NAL_CELFView_Epoch)
        print('NL_CELF in Epoch(%d):' % (Epoch + 1), Label_NL_CELFView_Epoch)
        print('Error Data------------------------------')

        NewNet = Model
        if Epoch>-1:
            A_Test = False
            if Epoch >= Epoch0-1:
                A_Test = True
            TestRate_N, TestRate_A = Test_Method_NewModel(NewNet, TestData_Loader, Method_Flag='CELF', A_Test=A_Test)

            if TestRate_N >= TestRate_Best[1]:
                TestRate_Best[1] = TestRate_N
                TestRate_Best[0] = Epoch + 1

        TestRecord_NA_Dict.update({Epoch + 1: [(TestRate_N, TestRate_A), (Label_NAL_CELFView_Epoch)]})
    # Save ------------------------
    Model_Path = Config.Model.Model_Path
    Model_Name = 'T0_CF10_L05_F[128]_E100_D[HC2]_CELF[L5]_SGD_IR[0.1]M[40_80]_H[NN]_OK'

    F_TestRecord = open(Model_Name + '.txt', 'w')
    F_TestRecord.write(str(TestRecord_NA_Dict))
    F_TestRecord.close()

    torch.save(Model.state_dict(), Model_Path + Model_Name + '.pkl')
    # Save ------------------------

    return TestRecord_NA_Dict, TestRate_Best
# Train the CNN model object with training data==================================================
