# Import Modules===============================================
# Import system modules-------------------------------------
#/usr/bin/env python
import os
# Import system modules-------------------------------------

# Import PyTorch Modules------------------------------------
import torch.utils.data as Data
from torchvision import datasets
# Import PyTorch Modules------------------------------------
# Import FunctionFiles modules------------------------------
print(os.path.dirname(__file__))
from Base_Setting_Function.F0_Setting_L05_CF10 import Config, Seed_Torch, DataTransform_Train_N, DataTransform_Test_N
from Base_Setting_Function.F3_Net_L05_OK import New_LeNet05_CEF0, New_LeNet05_CEOF0
from M0_ST_L05_HNN_OK.M0_Train_FineTune_OK import Train_Function
# Import FunctionFiles modules------------------------------
# Import Modules===============================================

# Set the GPU devices==========================================
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
# Set the GPU devices==========================================
Image_Size0 = Config.DB.ImageSize0
Number_Class0 = Config.DB.Num_Class0
Seed_Torch(seed=Config.OS.RandomSeed) # Set random seed

# Create a CNN Model object========
# Model0 = New_LeNet05_CEF0()
Model0 = New_LeNet05_CEOF0()
print(Model0)
# Create a CNN Model object========

# Config Check============================================
print('\n[ Config:-------------------------------------]')
print('|| Base:-------------------------------------')
print('|', 'RandomSeed:', Config.OS.RandomSeed)
for Config_K, Config_V in Config.DB.items():
    print('|', Config_K,':', Config_V)

print('|| Model:-------------------------------------')
for Config_K, Config_V in Config.Model.items():
    print('|', Config_K,':', Config_V)

print('|| Train:-------------------------------------')
for Config_K, Config_V in Config.Train.items():
    print('|', Config_K,':', Config_V)

print('|| Test:-------------------------------------')
for Config_K, Config_V in Config.Test.items():
    print('|', Config_K,':', Config_V)
print('[ Config:-------------------------------------]', '\n')

print('-------------------------------')
print('|| Number_Class0:', Number_Class0, '| Image_Size0:', Image_Size0, '| Image_MinMax0:',
      Config.DB.MinMax0, '| Feature_Dim:', Config.Model.Feature_Dim )
print('-------------------------------')
# Config Check============================================

# Import data===================================================================
ImagePath_Train0 = Config.Train.Data_Path
BatchSize_Train0 = Config.Train.Data_BatchSize

TrainDataSet_ImageFolder = datasets.CIFAR10(root=ImagePath_Train0, train=True,
                                            transform=DataTransform_Train_N, download=True)
TrainData_Loader = Data.DataLoader(TrainDataSet_ImageFolder, batch_size=BatchSize_Train0,
                                    num_workers=Config.Train.Data_Num_worker, pin_memory=True,
                                   shuffle=True, drop_last=True)

ImagePath_Test0 = Config.Test.Data_Path
BatchSize_Test0 = Config.Test.Data_BatchSize
TestDataSet_ImageFolder = datasets.CIFAR10(root=ImagePath_Test0, train=False,
                                           transform=DataTransform_Test_N)
TestData_Loader = Data.DataLoader(TestDataSet_ImageFolder, batch_size=BatchSize_Test0,
                                  num_workers=Config.Test.Data_Num_worker, pin_memory=True,
                                  shuffle=False, drop_last=False)

# Import data=======================================================================

# Train the CNN model object with training data and test performance of current model==============
Epoch0 = Config.Train.Epoch-20 # 100
print('-------------------------------')
print('|| Train_Start: |Epoch0', Epoch0, '| BatchSize0_Train', BatchSize_Train0, '| BatchSize0_Test', BatchSize_Test0)
print('-------------------------------')
Lamda = 0
TestRecord0, TestRate_Best = Train_Function(Model0, TrainData_Loader, Lamda, Epoch0, TestData_Loader)
print('TestRate_Best:', TestRate_Best)
# Train the CNN model object with training data and test performance of current model==============
