
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from Base_Setting_Function.F0_Setting_L05_CF10 import Config
from Base_Setting_Function.F4_LossFunction_OK import Label_CEOF_AELF0


# Init_LeNet5 ========================================================
class LeNet5(nn.Module):
    def __init__(self):
        super(LeNet5, self).__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1, stride=1)
        self.relu1 = nn.ReLU(inplace=True)
        self.maxpool1 = nn.MaxPool2d(2)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1, stride=1)
        self.relu2 = nn.ReLU(inplace=True)
        self.maxpool2 = nn.MaxPool2d(2)
        self.linear1 = nn.Linear(7*7*64, 200)
        self.relu3 = nn.ReLU(inplace=True)
        self.linear2 = nn.Linear(200, 10)

    def forward(self, x):
        out = self.maxpool1(self.relu1(self.conv1(x)))
        out = self.maxpool2(self.relu2(self.conv2(out)))
        out = out.view(out.size(0), -1)
        out = self.relu3(self.linear1(out))
        out = self.linear2(out)
        return out
# Init_LeNet5 =========================================================

# New_LeNet5 =========================================================
class New_LeNet05_CEF0(nn.Module):
    def __init__(self):
        super(New_LeNet05_CEF0, self).__init__()
        self.Feature = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(64, affine=True),
            nn.ReLU(),

            nn.Conv2d(64, 64, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(64, affine=True),
            nn.ReLU(),
            nn.AvgPool2d(2),

            nn.Conv2d(64, 128, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(128, affine=True),
            nn.ReLU(),
            nn.AvgPool2d(2),

            nn.Conv2d(128, 256, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(256, affine=True),
            nn.ReLU(),
            nn.AvgPool2d(2),

            nn.Conv2d(256, 512, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(512, affine=True),
            nn.ReLU(),
            nn.AvgPool2d(4),
        )
        self.FC =  nn.Sequential(
            nn.Linear(1 * 1 * 512, Config.Model.Feature_Dim, bias=False),
            nn.ReLU(),
        )

        self.Out = nn.Linear(Config.Model.Feature_Dim, 10, bias=False)

        # nn.init.constant_(self.FC.bias, 0)
        # nn.init.constant_(self.Out.bias, 0)

    def forward(self, x, Label):
        Label = None
        x = self.Feature(x)
        x = x.view(x.size(0), -1)
        x = self.FC(x)
        Output = self.Out(x)
        return Output, x
# New_LeNet5 =========================================================

# New_LeNet5 =========================================================
class New_LeNet05_CEOF0(nn.Module):
    def __init__(self):
        super(New_LeNet05_CEOF0, self).__init__()
        self.Feature = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(64, affine=True),
            nn.ReLU(),

            nn.Conv2d(64, 64, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(64, affine=True),
            nn.ReLU(),
            nn.AvgPool2d(2),

            nn.Conv2d(64, 128, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(128, affine=True),
            nn.ReLU(),
            nn.AvgPool2d(2),

            nn.Conv2d(128, 256, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(256, affine=True),
            nn.ReLU(),
            nn.AvgPool2d(2),

            nn.Conv2d(256, 512, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(512, affine=True),
            nn.ReLU(),
            nn.AvgPool2d(4),
        )
        self.FC =  nn.Sequential(
            nn.Linear(1 * 1 * 512, Config.Model.Feature_Dim, bias=False),
            nn.ReLU(),
        )

        self.Out = Label_CEOF_AELF0(Feature_Dim=Config.Model.Feature_Dim, Num_Class_Label=10)

        # nn.init.constant_(self.FC.bias, 0)
        # nn.init.constant_(self.Out.bias, 0)

    def forward(self, x, Label):
        Label = None
        x = self.Feature(x)
        x = x.view(x.size(0), -1)
        x = self.FC(x)
        CEF_Output, COF_Output = self.Out(x)
        return CEF_Output, (COF_Output, x)
# New_LeNet5 =========================================================
