from easydict import EasyDict as EDict
Config = EDict()
Config.OS = EDict()
Config.DB = EDict()
Config.LF = EDict()
Config.Model = EDict()
Config.Train = EDict()
Config.Test = EDict()


# Train_OS--------------------------------
Config.OS.RandomSeed = 0
# Train_OS--------------------------------
# Init_Image------------------------------
Config.DB.ImageSize0 = (32, 32)
Config.DB.Num_Class0 = 10
Config.DB.MinMax0 = [0.0, 1.0]
Config.DB.DA_HF = True
Config.DB.DA_HC = 2
# Init_Image------------------------------

# Model--------------------------------
Config.Model.Model_Path = '/home/SCB_FBP/FBP2_AELF_NN2023/NN_AELF_CF10_LeNet05_GHV/Model_FromMethod/'
Config.Model.Feature_Dim = 128
# Model--------------------------------


# TrainSet--------------------------------
Config.Train.Data_Path = '/home/Data_File0/Data_DB0/DB_Net/CF10_Net/'
Config.Train.Data_BatchSize = 256
Config.Train.Data_Num_worker = 0

Config.Train.Epoch = 120

Config.Train.RFlag_Dropout = False
Config.Train.RFlag_L2Norm = 0.0005

Config.Train.LR_SGD_LR0 = 0.1
Config.Train.LR_SGD_M_Epoch = [40, 80]
Config.Train.LR_SGD_M_BiLi = 0.1

Config.Train.AE_Flag_Target = False
Config.Train.AE_Flag_InitN = True
Config.Train.AE_P_Epoch = 8
Config.Train.AE_P_Ratio = 0.031 # 0.125
Config.Train.AE_P_Ratio_Once = 0.004
# TrainSet--------------------------------


# TestSet--------------------------------
Config.Test.Data_Path = '/home/Data_File0/Data_DB0/DB_Net/CF10_Net/'
Config.Test.Data_BatchSize = 500
Config.Test.Data_Num_worker = 2

Config.Test.AE_Flag_Target = False
Config.Test.AE_Flag_InitN = True # False
Config.Test.AE_P_Epoch = 8
Config.Test.AE_P_Ratio = [0.031]
Config.Test.AE_P_Ratio_Once = 0.004
# TestSet--------------------------------

# print('Config:', Config)
import random
import torch
import numpy as np
def Seed_Torch(seed=Config.OS.RandomSeed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True

from torchvision import transforms
DataTransform_Train_N = transforms.Compose([
        # transforms.Resize(Config.DB.ImageSize0),
        transforms.RandomHorizontalFlip(),
        transforms.RandomCrop(Config.DB.ImageSize0, padding=Config.DB.DA_HC),
        transforms.ToTensor(),
    ])

DataTransform_Test_N = transforms.Compose([
        # transforms.Resize(Config.Image.Size0),
        transforms.ToTensor(),
    ])