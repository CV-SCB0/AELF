import os
import torch
import numpy as np
from torch.autograd import Variable
import torch.nn as nn
import torch.optim as optim
from Base_Setting_Function.F0_Setting_L05_CF10 import Config
from Base_Setting_Function.F4_LossFunction_OK import Label_CELF0


class AE_PGD_SCB(nn.Module):
    def __init__(self, Model0):
        super().__init__()
        self.Model = Model0 # 必须是pytorch的model
        self.Device = torch.device("cuda" if (torch.cuda.is_available()) else "cpu")
        self.LF = Label_CELF0()

        self.Flag_Target = None  # 是否有目标攻击
        self.Flag_InitN = None  # 是否随机初始化

        self.AE_P_Epoch = None
        self.AE_P_Ratio = None  # Pertubation ratio
        self.AE_P_Ratio_Once = None  # self.Ratio_P/self.Epoch

        self.Data_Clip_Min = Config.DB.MinMax0[0]
        self.Data_Clip_Max = Config.DB.MinMax0[1]

    def AE_PGD_GP(self, X, Y, TT_Flag=None, LF_Flag=None):

        # Init Start---------------------------------------
        self.Model.zero_grad()
        if TT_Flag=='Train':
            if LF_Flag == 'CELF':
                pass
            else:
                print('PGD Init LF: Error, Error!')
            self.Model.eval()

        elif TT_Flag=='Test':
            pass
        else:
            print('PGD Init TT: Error, Error!')
        # Init Start---------------------------------------

        X0 = X.cuda()
        Label0 = Y.cuda()

        # Init Noise---------------------------------------
        if self.Flag_InitN:
            # PGD: np.random.uniform(-self.epsilon, self.epsilon, x_nat.shape)
            Init_Noise0 = torch.tensor(np.random.uniform(-self.AE_P_Ratio, self.AE_P_Ratio, X0.shape)).type_as(X0)
        else:
            Init_Noise0 = 0
        # Init Noise---------------------------------------

        X_A_InitN0 = X0 + Init_Noise0
        X_A_InitN = torch.clamp(X_A_InitN0, self.Data_Clip_Min, self.Data_Clip_Max)
        AE_P_InitN = X_A_InitN - X0

        AE_P_New = AE_P_InitN
        for i in range(self.AE_P_Epoch):
            AE_P_New = self.AE_GP_OneEpoch(X0, Label0, P_Prev=AE_P_New)
        AE_PGD_P = AE_P_New

        # Init End---------------------------------------
        self.Model.zero_grad()
        if TT_Flag=='Train':
            if LF_Flag == 'CELF':
                pass
            else:
                print('PGD End LF: Error, Error!')
            self.Model.train()
        elif TT_Flag=='Test':
            pass
        else:
            print('PGD End TT: Error, Error!')
        # Init End---------------------------------------
        return AE_PGD_P.cpu()

    def AE_GP_OneEpoch(self, X0, Label0, P_Prev):

        X_A_Temp0 = X0 + P_Prev
        X_A_Temp0.requires_grad = True

        self.Model.zero_grad()
        Output_Model, _ = self.Model(X_A_Temp0, Label0)
        Label_LFOut = 0
        if self.Flag_Target:
            print('!!------Aim_Attack------!!')
        else:
            Label_LFOut = self.LF(Output_Model, Label0)

        Label_LFOut.backward()
        GradSign_Temp0 = X_A_Temp0.grad.data.sign()
        # CUDA-----------------------------------

        # Pertubation of Sum----------------------
        GradValue_OneEpoch = self.AE_P_Ratio_Once * GradSign_Temp0
        # P_OneEpoch = torch.clamp(GradValue_OneEpoch, -self.AE_P_Ratio, self.AE_P_Ratio)

        X_A_TempP = X_A_Temp0 + GradValue_OneEpoch
        P_OneEpoch = torch.clamp(X_A_TempP, self.Data_Clip_Min, self.Data_Clip_Max) - X0
        P_OneEpoch_OK = torch.clamp(P_OneEpoch, -self.AE_P_Ratio, self.AE_P_Ratio)
        # Pertubation of Sum----------------------

        return P_OneEpoch_OK.detach()


class PGD_Trades(nn.Module):
    def __init__(self, Model0):
        super().__init__()
        self.Model = Model0 # 必须是pytorch的model
        self.Loss_F = Label_CELF0()

        self.Flag_Rand_Init = False  # 是否随机初始化
        self.Flag_Target = False  # 是否有目标攻击
        self.Flag_LF = None

        self.Ratio_N = None
        self.Ratio_P = None  # Pertubation ratio
        self.Epoch = None
        self.Ratio_P_OneStep = None # self.Ratio_P/self.Epoch

        self.Clip_Min = 0.0
        self.Clip_Max = 1.0

    def PGD_Attack(self, X, y, TT_Flag=None, LF_Flag=None):
        self.Model.zero_grad()
        self.Model.eval()

        if LF_Flag=='CELF':
            pass
        else:
            print('Error, Error!')

        X0 = X.cuda()
        Label0 = y.cuda()

        X_PGD = Variable(X0.data, requires_grad=True)
        if self.Flag_Rand_Init:
            random_noise = torch.FloatTensor(*X_PGD.shape).uniform_(-self.Ratio_P, self.Ratio_P)
            X_PGD = Variable(X_PGD.data + random_noise, requires_grad=True)

        for _ in range(self.Epoch):
            opt = optim.SGD([X_PGD], lr=1e-3)
            opt.zero_grad()

            with torch.enable_grad():
                loss = self.Loss_F(self.Model(X_PGD, 'Label')[0], Label0)
            loss.backward()
            eta = self.Ratio_P_OneStep * X_PGD.grad.data.sign()
            X_PGD = Variable(X_PGD.data + eta, requires_grad=True)
            eta = torch.clamp(X_PGD.data - X0.data, -self.Ratio_P, self.Ratio_P)
            X_PGD = Variable(X0.data + eta, requires_grad=True)
            X_PGD = Variable(torch.clamp(X_PGD, 0, 1.0), requires_grad=True)
        Adv_P = X_PGD-X0

        self.Model.zero_grad()
        if TT_Flag == 'Train':
            self.Model.train()
        elif TT_Flag == 'Test':
            pass
        else:
            print('Error, Error!')

        return Adv_P.cpu()
