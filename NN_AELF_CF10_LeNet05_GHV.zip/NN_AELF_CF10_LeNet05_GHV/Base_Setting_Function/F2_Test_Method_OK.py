# Import PyTorch Modules------------------------------------
import os
import torch
import torch.nn as nn
from Base_Setting_Function.F0_Setting_L05_CF10 import Config
# Import PyTorch Modules------------------------------------

# Import FunctionFiles modules------------------------------
from Base_Setting_Function.F1_AE_PGD_GPU_OK import AE_PGD_SCB
# Import FunctionFiles modules------------------------------

# Define functions ============================================================================================
def Recognition_Test_Model(NewModel, TestData_Loader, A_Test, LF_Flag):

    # Test Normal Image-----------------------------------------
    Number_N_OK = 0
    Number_N = 0
    for step, (Image_N_0, Label_N_0) in enumerate(TestData_Loader):

        Image_N = Image_N_0.cuda()
        Label_N = Label_N_0.cuda()

        Output_N, _ = NewModel(Image_N, Label_N)
        _, Predict_N = torch.max(Output_N, 1)

        # print('Check------>', Predict_N, LabelFlag, (Predict_N==LabelFlag).int().sum(),
        #       (Predict_N==LabelFlag).int().sum())
        Number_N = Number_N + Label_N.size(0)
        Number_N_OK = Number_N_OK + (Predict_N==Label_N).sum()

    Rate_N = Number_N_OK.__float__()/Number_N
    Rate_N = round(Rate_N, 4)
    TestRate_N = Rate_N
    # Test Normal Image-----------------------------------------

    # Test Adv Image-----------------------------------------
    TestRate_A = {}
    if A_Test == True:
        PGD_Model_Test = AE_PGD_SCB(NewModel)

        PGD_Model_Test.Flag_Target = Config.Test.AE_Flag_Target # False
        PGD_Model_Test.Flag_InitN = Config.Test.AE_Flag_InitN # True

        PGD_Model_Test.AE_P_Epoch = Config.Test.AE_P_Epoch
        PGD_Model_Test.AE_P_Ratio= Config.Test.AE_P_Ratio
        PGD_Model_Test.AE_P_Ratio_Once = Config.Test.AE_P_Ratio_Once

        print(
            '|| Test_PGD_Check-> | AE_Method:', 'PGD',
            '| PGD_Flag_Target: ', PGD_Model_Test.Flag_Target,
            '| PGD_Flag_InitN: ', PGD_Model_Test.Flag_InitN,

            '| PGD_P_Max_Min: [' + str(PGD_Model_Test.Data_Clip_Min) + ', ' + str(PGD_Model_Test.Data_Clip_Max) + ']',
            '| PGD_Epoch:', PGD_Model_Test.AE_P_Epoch,
            '| PGD_InitN:', PGD_Model_Test.AE_P_Ratio,
            '| PGD_P:', PGD_Model_Test.AE_P_Ratio,
            '| PGD_P_Once:', PGD_Model_Test.AE_P_Ratio_Once)

        for Ratio_P in PGD_Model_Test.AE_P_Ratio:
            Number_A_OK = 0
            Number_A = 0
            for step, (Image_N_0, Label_N_0) in enumerate(TestData_Loader):

                PGD_Model_Test.AE_P_Ratio = Ratio_P
                PGD_P = PGD_Model_Test.AE_PGD_GP(Image_N_0, Label_N_0, TT_Flag='Test', LF_Flag=LF_Flag)
                Image_A_0 = Image_N_0 + PGD_P

                Image_A = Image_A_0.cuda()
                Label_A = Label_N_0.cuda()
                Output_A, _ = NewModel(Image_A, Label_A)

                _, Predict_A = torch.max(Output_A, 1)
                Number_A = Number_A + Label_A.size(0)
                Number_A_OK = Number_A_OK + (Predict_A == Label_A).sum()

            Rate_A = Number_A_OK.__float__() / Number_A
            Rate_A = round(Rate_A, 4)
            E_Name = 'P['+str(Ratio_P)+']'
            TestRate_A.update({E_Name: Rate_A})
    else:
        TestRate_A = None
    # Test Adv Image-----------------------------------------
    return (TestRate_N, TestRate_A)

def Test_Method_NewModel(New_Model, TestData_Loader, Method_Flag='CELF', A_Test=False):

    if Method_Flag=='CELF':
        print('Check------>CELF')
    elif Method_Flag=='PGD':
        print('Check------>PGD')
    elif Method_Flag=='BIM':
        print('Check------>BIM')
    elif Method_Flag == 'TRADES':
        print('Check------>TRADES')
    elif Method_Flag=='AELF':
        print('Check------>AELF')
    else:
        print('Test Start: Error, Error!')
    New_Model.eval()

    # NN---------------------------------------
    N_Test_Rate, A_Test_Rate = Recognition_Test_Model(New_Model, TestData_Loader, A_Test, 'CELF')
    print('N_Test_Rate:', N_Test_Rate)
    print('A_Test_Rate:', A_Test_Rate)
    # NN---------------------------------------

    if Method_Flag=='CELF':
        print('Check------>CELF\n')
    elif Method_Flag=='PGD':
        print('Check------>PGD\n')
    elif Method_Flag=='BIM':
        print('Check------>BIM\n')
    elif Method_Flag == 'TRADES':
        print('Check------>TRADES\n')
    elif Method_Flag=='AELF':
        print('Check------>AELF\n')
    else:
        print('Test Start: Error, Error!')

    A_Test_Rate = A_Test_Rate

    New_Model.train()
    return N_Test_Rate, A_Test_Rate
