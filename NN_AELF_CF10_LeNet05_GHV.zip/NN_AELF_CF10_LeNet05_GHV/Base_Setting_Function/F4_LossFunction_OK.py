from collections import defaultdict
import math
import torch
import torch.nn as nn
import torch.nn.functional as F

# CE_LF=========================================================
class Label_CELF0(nn.Module):
    def __init__(self, ):
        super(Label_CELF0, self).__init__()
        self.CELoss = nn.NLLLoss()
    def forward(self, Output, Label):
        Output = F.log_softmax(Output, 1)
        CELF_Distance = self.CELoss(Output, Label)
        return CELF_Distance
# CE_LF=========================================================

# CECOF=========================================================
class Label_CEOF_AELF0(nn.Module):
    def __init__(self, Feature_Dim=None, Num_Class_Label=None):
        super(Label_CEOF_AELF0, self).__init__()
        self.w = torch.nn.Parameter(torch.Tensor(Num_Class_Label, Feature_Dim))
        nn.init.kaiming_uniform_(self.w, a=math.sqrt(5))
    def forward(self, X):
        # W_N0 = F.normalize(self.W)
        X_N0 = F.normalize(X)

        COF_D0 = F.linear(X_N0, self.w)
        CEF_D0 = F.linear(X, self.w)

        return CEF_D0, COF_D0
# CECOF=========================================================