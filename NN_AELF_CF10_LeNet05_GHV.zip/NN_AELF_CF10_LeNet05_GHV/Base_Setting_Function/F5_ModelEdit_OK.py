import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.utils
try:
    torch._utils. _rebuild_tensor_v2
except AttributeError:
    def _rebuild_tensor_v2(storage, storage_offset, size, stride, requires_grad, backward_hooks):
        tensor = torch._utils._rebuild_tensor(storage, storage_offset, size, stride)
        tensor.requires_grad = requires_grad
        tensor._backward_hooks = backward_hooks
        return tensor
    torch._utils._rebuild_tensor_v2 = _rebuild_tensor_v2
# Model Read==================================================================

# Model Read==================================================================
# GPU <-> CPU change ------------------------------
def Model_ReadCNN0(NewNet, Model_Name=None, Model_Path= None, Flag='W'):
    Model_Path = Model_Path + Model_Name
    if Flag == 'W':
        NewNet.load_state_dict(torch.load(Model_Path))
    elif Flag == 'L':
        Original_dict = torch.load(Model_Path)

        from collections import OrderedDict
        NewOriginal_Dict = OrderedDict()
        for k, v in Original_dict.items():
            name = k[0:] # remove 'module'
            # if name=='Out.W':
            NewOriginal_Dict[name] = v

        NewNet_Dict = NewNet.state_dict() # state_dict() is the another status(state) or converted express way of Net

        # remove the key that isn't exit in NewNet_Dict from PreTrained_Dict
        PreTrained_Dict = {k: v for k, v in NewOriginal_Dict.items() if k in NewNet_Dict}
        NewNet_Dict.update(PreTrained_Dict)
        NewNet.load_state_dict(NewNet_Dict)

    return NewNet
# GPU <-> CPU change ------------------------------
# Model Read==================================================================

# Model Read==================================================================
def Model_ReadCNN_FW(NewNet, ModelName='M_L09_O.pkl', Model_Path= None, Flag='L'):
    Model_Direction = Model_Path + ModelName
    if Flag == 'W':
        NewNet.load_state_dict(torch.load(Model_Direction))
    elif Flag == 'L':
        Original_dict = torch.load(Model_Direction)
        NewNet_Dict = NewNet.state_dict()
        # Change the name of Pretrain model stict----------
        for k, v in Original_dict.items():
            name = k[0:] # remove 'module'
            print(name)
            if 'Out.' in name:
                # NewOriginal_Dict[name] = F.normalize(v.clone(), p=2, dim=1)
                NewNet_Dict[name] = v
                print('OK, OK:', name)
            # elif 'FC.' in name:
            #     NewOriginal_Dict[name] = v
            #     print('OK, OK:', name)
            else:
                pass
                # NewOriginal_Dict[name] = v
        # Change the name of Pretrain model stict----------

        NewNet.load_state_dict(NewNet_Dict)

    return NewNet
# Model Read==================================================================

# Model Integration-----------------------------------------------------------
class Model_Combination_CEF(nn.Module):
    def __init__(self, Model_Feature, Model_Out):
        super(Model_Combination_CEF, self).__init__()
        self.Feature = Model_Feature
        self.Out = Model_Out
    def forward(self, x):
        x = self.Feature(x)
        Output = self.Out(x)
        return Output
# Model Integration-----------------------------------------------------------

# Model Integration-----------------------------------------------------------
class Model_Combination_CosF(nn.Module):
    def __init__(self, Model_Feature, Model_Out):
        super(Model_Combination_CosF, self).__init__()
        self.Feature = Model_Feature
        self.Out = Model_Out
    def forward(self, x, Label):
        x = self.Feature(x)
        Output = self.Out(x, Label)
        return Output
# Model Integration-----------------------------------------------------------