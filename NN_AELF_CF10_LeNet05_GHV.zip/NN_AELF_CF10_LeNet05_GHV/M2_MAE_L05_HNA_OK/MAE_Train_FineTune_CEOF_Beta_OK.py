# Import system modules-------------------------------------
import time
import torch
from torch.optim import lr_scheduler
# Import system modules-------------------------------------
from Base_Setting_Function.F0_Setting_L05_CF10 import Config
from Base_Setting_Function.F1_AE_PGD_GPU_OK import AE_PGD_SCB
from Base_Setting_Function.F2_Test_Method_OK import Test_Method_NewModel
from Base_Setting_Function.F4_LossFunction_OK import Label_CELF0

# Train the CNN model ==================================================
def Train_Function(Model, TrainData_Loader, Beta, Epoch0, TestData_Loader):
    Lamda = [1, 1]
    Batch_HL = int(Config.Train.Data_BatchSize/2) # Half Line
    Model.Out.requires_grad = False

    print('-------------------------------')
    print('|| CELF:', 'True')
    print('-------------------------------')

    Label_CELFModel = Label_CELF0()

    # Set the GPU devices--------------------------------
    if torch.cuda.is_available():
        Model.cuda()
        Label_CELFModel.cuda()
    # Set the GPU devices--------------------------------

    # Train Setting--------------------------------------
    L2Norm = Config.Train.RFlag_L2Norm
    LR0 = Config.Train.LR_SGD_LR0
    LR_M_Epoch_Num = Config.Train.LR_SGD_M_Epoch
    LR_M_Epoch_BiLi = Config.Train.LR_SGD_M_BiLi

    print('Training setting---------------')
    print('|| LRO:', LR0, 'LR_M:', LR_M_Epoch_Num, 'LR_BiLi:', LR_M_Epoch_BiLi, '| Weight_Decay0:', L2Norm,
          '| AE:', None, '| DropOut:', Config.Train.RFlag_Dropout)
    print('Training setting---------------')

    Params_Feature = [{'params': Model.Feature.parameters()}, {'params': Model.FC.parameters()}]
    # Params_Feature = [{'params': Model.Feature.parameters()}]
    Optimizer_Feature = torch.optim.SGD(Params_Feature, lr=LR0, momentum=0.9, weight_decay=L2Norm)
    Scheduler_Feature = lr_scheduler.MultiStepLR(Optimizer_Feature, milestones=[40, 80], gamma=0.1, last_epoch=-1)
    # Train Setting--------------------------------------

    # AA Set------------------------------------------
    PGD_Model = AE_PGD_SCB(Model)

    PGD_Model.Flag_Target = Config.Train.AE_Flag_Target
    PGD_Model.Flag_InitN = Config.Train.AE_Flag_InitN

    PGD_Model.AE_P_Epoch = Config.Train.AE_P_Epoch
    PGD_Model.AE_P_Ratio = Config.Train.AE_P_Ratio
    PGD_Model.AE_P_Ratio_Once = Config.Train.AE_P_Ratio_Once

    print(
        '|| Train_PGD_Check--> '
        '| PGD_Flag_Target: ', PGD_Model.Flag_Target,
        '| PGD_Flag_InitN: ', PGD_Model.Flag_InitN,

        '| PGD_P_Max_Min: [' + str(PGD_Model.Data_Clip_Min) + ', ' + str(PGD_Model.Data_Clip_Max) + ']',
        '| PGD_P_Epoch:', PGD_Model.AE_P_Epoch,
        '| PGD_P:', PGD_Model.AE_P_Ratio,
        '| PGD_P_Once:', PGD_Model.AE_P_Ratio_Once,
        '-->OK')
    print('-------------------------------\n')
    # AA Set------------------------------------------

    # training the CNN model----------------------------------------------
    TestRecord_NA_Dict = {}
    TestRate_Best = [0, 0]
    for Epoch in range(0, Epoch0):
        Start_Time = time.time()
        RandomSeed = Config.OS.RandomSeed

        Model.train()
        Label_NAL_CELFView = 0

        if Epoch == 0:
            TestRate_N, TestRate_A = Test_Method_NewModel(Model, TestData_Loader, Method_Flag='AELF', A_Test=False)
            TestRecord_NA_Dict.update({Epoch + 1: [(TestRate_N, TestRate_A), (None)]})
        for StepI, (N_Image0, N_Label0) in enumerate(TrainData_Loader):

            # Gene Adv Image--------------------------------------------
            # print(Config.Train.BatchSize/2)
            N_Label = N_Label0[0:Batch_HL]
            N_Image = N_Image0[0:Batch_HL, :]

            A_Label = N_Label0[Batch_HL:].clone().detach()
            A_Image = N_Image0[Batch_HL:, :].clone().detach()
            PGD_P = PGD_Model.AE_PGD_GP(A_Image, A_Label, TT_Flag='Train', LF_Flag='CELF')
            A_ImageP = A_Image + PGD_P.clone().detach()
            # Gene Adv Image--------------------------------------------
            # print(N_Label0.size(), N_Label.size(), A_Label.size())
            NA_Image = torch.cat((N_Image, A_ImageP), 0)
            NA_Label = torch.cat((N_Label, A_Label), 0)

            NA_Image = NA_Image.cuda()
            NA_Label = NA_Label.cuda()

            Label_NA_CEFOut, (Label_NA_COFOut, Feature_NA_Out) = Model(NA_Image, NA_Label)

            NLabel_CELFOut = Label_CELFModel(Label_NA_CEFOut[0:Batch_HL, :], NA_Label[0:Batch_HL])

            ALabel_COLFOut = Label_CELFModel(Label_NA_COFOut[Batch_HL:, :], NA_Label[Batch_HL:])

            AFeature_NormOut_V, AFeature_NormOut_M = torch.var_mean(torch.norm(Feature_NA_Out[Batch_HL:, :],  p=2, dim=1))

            NA_LabelFeature_LFOut = Lamda[0] * NLabel_CELFOut + Beta * (Lamda[1] * ALabel_COLFOut + torch.clamp(AFeature_NormOut_M-1, min=0))
            Optimizer_Feature.zero_grad()
            NA_LabelFeature_LFOut.backward()
            Optimizer_Feature.step()

            # Eval error--------------------------------------
            Label_NAL_CELFView  = Label_NAL_CELFView  + NA_LabelFeature_LFOut.item()  #
            # Eval error--------------------------------------
        Scheduler_Feature.step()
        print('Error Data==============================================')
        End_Time = time.time()
        Epoch_Time = round((End_Time - Start_Time) / 60, 2)
        print('[Lamda:', Lamda, '|Beta:', Beta, '| Epoch:', Epoch + 1, "| OS RandomSeed:", RandomSeed, '| LR:',
              round(Optimizer_Feature.param_groups[0]['lr'], 6), '| L2Norm:', L2Norm, '| Time:', Epoch_Time, '|]')
        print('Error Data----------------------------------')
        Label_NAL_CELFView_Epoch = round(Label_NAL_CELFView / (StepI + 1), 4)

        if (Epoch+1) % 1 == 0:
            print('Error Data------------------------------')
            print('NALF_CELF in Epoch(%d):' % (Epoch + 1), Label_NAL_CELFView_Epoch)
            print('Error Data------------------------------')
        else:
            print('OK, OK ------>\n')
        # Save the trained model---------------------------------------------------

        NewNet = Model
        if  (Epoch+1) % 2 == 0:
            A_Test = False
            if Epoch >= Epoch0-1:
                A_Test = True
            TestRate_N, TestRate_A = Test_Method_NewModel(NewNet, TestData_Loader, Method_Flag='AELF', A_Test=A_Test)
            TestRecord_NA_Dict.update({Epoch + 1: (TestRate_N, TestRate_A)})

            if TestRate_N >= TestRate_Best[1]:
                TestRate_Best[1] = TestRate_N
                TestRate_Best[0] = Epoch + 1
            TestRecord_NA_Dict.update({Epoch + 1: [(TestRate_N, TestRate_A), (Label_NAL_CELFView_Epoch)]})

    # Save ------------------------
    Model_Path = Config.Model.Model_Path
    Model_Name = 'T2_TAE_CF10_L05_F[128]_E120_D[HC2]_CEOF[L5]_SGD_IR[0.1]M[40_80]_PGD[P0.031_E8_OP0.004]_B['+str(Beta)+']_H[N'\
                       +str(Lamda[0])+'_A'+str(Lamda[1])+']_OK'

    F_TestRecord = open(Model_Name + '.txt', 'w')
    F_TestRecord.write(str(TestRecord_NA_Dict))
    F_TestRecord.close()

    torch.save(Model.state_dict(), Model_Path + Model_Name + '.pkl')
    # Save ------------------------

    return TestRecord_NA_Dict, TestRate_Best
# Train the CNN model object with training data==================================================
